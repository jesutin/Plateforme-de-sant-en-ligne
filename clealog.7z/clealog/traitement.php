

<!DOCTYPE >
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Docteur intelligent</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

  </head>

<?php
    //ouvrez la connexion avec la bases de données

  $user = 'root';
  $pass= '';

   $dbc = new PDO('mysql:host=localhost;dbname=crealog',$user,$pass);
  

   //activez les exceptions

   $dbc->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // recuperer le formullaire

   $first_name = $_POST["first_name"];
   $last_name =$_POST["last_name"];
   $adress  = $_POST["adress"];

   $email = $_POST["email"];
   $city = $_POST["city"];
   $ddate = $_POST["ddate"];

   $password = $_POST["password"];
   $c_password = $_POST ["c_password"];
   $passwords = password_hash($_POST["password"], PASSWORD_DEFAULT);
   $c_passwords = password_hash($_POST["c_password"], PASSWORD_DEFAULT);

 //verification 


 


//Si le mot de passe est vide ou différent l'un l'autre
if (empty($_POST['password']) || $_POST['password'] != $_POST['c_password']){
	
  echo("<div class=\"alert alert-danger fade in\">
    <a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>
    <strong>Error!</strong> Your password is not conform.
</div>");
}

elseif (empty($_POST['first_name']) || !preg_match('/^[a-zA-Z0-9_]+$/', $_POST['first_name'])) {
	
   echo "<div class=\"alert alert-danger fade in\">
    <a href=\"#\" class=\"close\" data-dismiss=\"alert\">&times;</a>
    <strong>Error!</strong> first name has a pr.
</div>";
}


elseif (empty($_POST['last_name']) || !preg_match('/^[a-zA-Z0-9_]+$/', $_POST['last_name'])) {
	
   echo "<div class=\"alert alert-danger fade in\">
   
    <strong>Error!</strong> A problem has been occurred while submitting your data.
</div>";
}

elseif(empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
    echo  "<div class=\"alert alert-danger fade in\">
    <a href=\"\" class=\"close\" data-dismiss=\"alert\">&times;</a>
    <strong>Error!</strong> A problem has been occurred while submitting your data.
</div>";
}


else{


   $sql1= 'INSERT INTO inscription (first_name, last_name,adress,email,city,ddate,password, c_password) VALUES
   (:first_name,  :last_name, :adress, :email, :city,:ddate, :passwords, :c_passwords)';
     
  $stm = $dbc->prepare($sql1);

  $stm ->execute( array(
    'first_name' =>$first_name, 
    'last_name' =>$last_name, 
    'adress' =>$adress, 
    'email' =>$email, 
    'city' =>$city, 

    'ddate' =>$ddate, 
    'passwords' =>$passwords, 
    'c_passwords' =>$c_passwords
   ));

 echo"<div class=\"alert alert-success fade in\">
      <a href=\"inscription.php\" class=\"close\" data-dismiss=\"alert\">&times;</a>
          <strong>Success!</strong> Your message has been sent successfully.
      </div>";

}

   






?>


</html >