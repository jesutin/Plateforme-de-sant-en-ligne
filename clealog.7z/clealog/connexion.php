<?php
    //ouvrez la connexion avec la bases de données

  $user = 'root';
  $pass= '';

   $dbc = new PDO('mysql:host=localhost;dbname=crealog',$user,$pass);
  

   //activez les exceptions

   $dbc->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // recuperer le formullaire

   $password = $_POST['password'];
   $email = $_POST['email'];
   $pass_hash = password_hash($_POST['password'],PASSWORD_DEFAULT);
   $req = $dbc->prepare('SELECT * FROM inscription WHERE email= :email');
   $req->execute(array(':email' =>$email));
       
   /*$req->execute (
        array(':email' =>$email,

             ':password' =>$pass_hash));AND password= :password*/

    $resultat = $req->fetch();
    //var_export($resultat);
    //die();

    if(!$resultat){


       echo "mail ou mot de passe incorrect";
       var_export($resultat);


    }

   else
   {

    session_start();

    $_SESSION['id'] = $resultat['id'];
    $_SESSION['email'] = $email;
    echo 'Vous êtes connecté !';


   }


  ?>